# License System Setup - Quick Guide

**Version**: 2.1.3 | **License System**: Multi-Binding Offline v2.0  
**Updated**: November 14, 2025

## ⚡ Quick Setup (5 Steps)

### 1️⃣ Generate RSA Keys (Vendor - One Time)
```powershell
python tools/license_generator.py generate-keys
```

**Output**: Creates `keys/private_key.pem` and `keys/public_key.pem`

⚠️ **CRITICAL**: Keep `private_key.pem` secure! Never commit to version control.

---

### 2️⃣ Embed Public Key in Code (Vendor)
1. Open `keys/public_key.pem`
2. Copy **entire** content (including `-----BEGIN PUBLIC KEY-----` and `-----END PUBLIC KEY-----`)
3. Paste into `src/tibmigrator/license/offline_validator.py` (lines 29-33)
4. Replace the `PUBLIC_KEY_PEM` constant

---

### 3️⃣ Rebuild Package (Vendor)
```powershell
python build_package.py --bytecode
```

**Output**: Creates `dist/tibmigrator-2.1.3-py3-none-any.whl`

---

### 4️⃣ Generate License (Vendor)

**Option A: Hardware-Bound License** (Single Machine)
```powershell
# Customer provides their machine ID
pip install dist/tibmigrator-2.1.3-py3-none-any.whl
tibmigrator get-machine-id

# Generate license for specific machine
python tools/license_generator.py generate `
    --binding hardware `
    --machine-id <CUSTOMER_MACHINE_ID> `
    --customer "John Doe" `
    --company "Acme Corp" `
    --type commercial `
    --output customer_license.json
```

**Option B: Subnet-Bound License** (Office Network)
```powershell
# Customer provides their network info
tibmigrator get-network-info

# Generate license for subnet
python tools/license_generator.py generate `
    --binding subnet `
    --allowed-subnets 192.168.1.0/24 10.0.0.0/16 `
    --max-machines 100 `
    --customer "IT Department" `
    --company "Acme Corp" `
    --type commercial `
    --output office_license.json
```

**Option C: Multi-Binding License** (Flexible)
```powershell
# Generate license with multiple binding options
python tools/license_generator.py generate `
    --binding multi `
    --allowed-machines laptop1 laptop2 `
    --allowed-subnets 192.168.0.0/16 `
    --allowed-domains company.com `
    --max-machines 500 `
    --customer "Enterprise Corp" `
    --company "Enterprise Corp" `
    --type commercial `
    --output enterprise_license.json
```


---

### 5️⃣ Install & Test License (Customer)
```powershell
# Install the package
pip install tibmigrator-2.1.3-py3-none-any.whl

# Install license file received from vendor
tibmigrator install-license customer_license.json

# Verify license is valid
tibmigrator license-status

# Start MCP server (license validation happens automatically)
tibmigrator
```

**Expected Output (Valid License):**
```
🔐 Validating license...
📜 License Information:
   Type: COMMERCIAL
   Binding: HARDWARE
   Licensed to: John Doe
   Company: Acme Corp
   Valid until: Perpetual
   Enabled features:
      ✓ reverse_engineering
      ✓ forward_engineering
      ✓ csv_export
      ✓ document_generation

🚀 Starting TIBMigrator MCP Server in stdio mode
```

**Expected Output (No License):**
```
❌ LICENSE VALIDATION FAILED
   Reason: No license file found

📋 To get your machine ID:
   tibmigrator get-machine-id

🌐 To get your network information:
   tibmigrator get-network-info

📥 To install a license:
   tibmigrator install-license /path/to/license.json

[Process exits with code 1 - SERVER DOES NOT START]
```

---

## 🔐 Server Startup Protection (NEW!)

**IMPORTANT**: The MCP server will **NOT start** without a valid license!

- ✅ License validated **before** server initialization
- ✅ Clear error messages with helpful commands
- ✅ Exit code 1 for automation/scripting
- ✅ Works with all 5 binding types

**This means:**
- Users **must** install a valid license to use the MCP server
- All MCP tools are protected (server won't start without license)
- CLI commands for license management still work (by design)

---

## 📋 Available CLI Commands

| Command | Purpose | Requires License? |
|---------|---------|-------------------|
| `tibmigrator get-machine-id` | Get hardware fingerprint | ❌ No |
| `tibmigrator get-network-info` | Get IP/subnet/domain info | ❌ No |
| `tibmigrator install-license <file>` | Install license file | ❌ No |
| `tibmigrator license-status` | Check license validity | ❌ No |
| `tibmigrator remove-license` | Remove installed license | ❌ No |
| `tibmigrator` (start server) | Start MCP server | ✅ **YES** |

---

## ✅ Verification Checklist

### Vendor Setup:
- [ ] RSA keys generated in `keys/` directory
- [ ] Public key embedded in `offline_validator.py`
- [ ] `keys/private_key.pem` backed up securely
- [ ] `keys/` directory added to `.gitignore`
- [ ] Package rebuilt with `--bytecode` flag
- [ ] Test license generated and validated

### Customer Setup:
- [ ] Package installed via pip
- [ ] Machine ID or network info obtained
- [ ] License file received from vendor
- [ ] License installed to `~/.tibmigrator/license.json`
- [ ] `tibmigrator license-status` shows VALID
- [ ] Server starts successfully with license info displayed
- [ ] Server blocks startup without license (test by removing license)

---

## 🚀 Binding Types Quick Reference

| Type | Use Case | Customer Provides | Vendor Uses |
|------|----------|-------------------|-------------|
| **hardware** | Single machine | `tibmigrator get-machine-id` | `--binding hardware --machine-id <ID>` |
| **subnet** | Office network | `tibmigrator get-network-info` | `--binding subnet --allowed-subnets <CIDR>` |
| **domain** | Enterprise org | Email domain | `--binding domain --allowed-domains <DOMAIN>` |
| **multi** | Flexible (OR) | Machine ID + network info | `--binding multi --allowed-machines ... --allowed-subnets ...` |
| **hybrid** | Strict (AND) | Machine ID + network info | `--binding hybrid --machine-id ... --allowed-subnets ...` |

---

## 🎯 Testing Scenarios

### Test 1: No License (Server Should Block)
```powershell
# Remove license if exists
tibmigrator remove-license

# Try to start server
tibmigrator
# Expected: Error message, exit code 1, server does NOT start
```

### Test 2: Valid License (Server Should Start)
```powershell
# Install license
tibmigrator install-license test_license.json

# Start server
tibmigrator
# Expected: License info displayed, server starts normally
```

### Test 3: Expired License (Server Should Block)
```powershell
# Generate expired license
python tools/license_generator.py generate --expires 2020-01-01 ...

# Install and try to start
tibmigrator install-license expired_license.json
tibmigrator
# Expected: "License expired" error, exit code 1
```

---

## 🚨 CRITICAL SECURITY

### ⚠️ NEVER Commit These Files:
```gitignore
# Add to .gitignore
keys/
*.pem
*_license.json
test_license.json
.tibmigrator/
```

### ✅ Security Best Practices:
1. **Private Key**: Store in password manager or HSM
2. **Backup**: Multiple secure locations (encrypted)
3. **Access Control**: Restrict to authorized personnel only
4. **Rotation**: Consider key rotation for long-term deployments
5. **Audit**: Log all license generations with customer info

---

## 📚 More Documentation

| Need | See Document |
|------|-------------|
| **Full Documentation** | `LICENSE_SYSTEM_README.md` |
| **Multi-Binding Details** | `MULTI_BINDING_LICENSE_COMPLETE.md` |
| **Security Best Practices** | `LICENSE_GITIGNORE_SECURITY.md` |
| **Implementation Summary** | `LICENSE_FINAL_SUMMARY.md` |
| **This Quick Guide** | `LICENSE_SETUP_QUICK.md` |

---

## 💡 Common Issues & Solutions

### Issue: "No license file found"
**Solution**: Install license with `tibmigrator install-license <file>`

### Issue: "License signature verification failed"
**Solution**: Ensure public key is correctly embedded in `offline_validator.py`

### Issue: "Hardware ID mismatch"
**Solution**: License was generated for different machine. Get correct machine ID with `tibmigrator get-machine-id`

### Issue: "No IP address matches allowed subnets"
**Solution**: 
1. Run `tibmigrator get-network-info` to see current IPs
2. Ensure license includes correct subnet (CIDR notation)
3. May need multi-binding license for VPN/remote scenarios

### Issue: Server starts but shows license warning
**Solution**: This shouldn't happen anymore - server **blocks** without valid license!

---

**Setup Status**: Ready for Production ✅  
**Server Protection**: Enabled ✅  
**Next Step**: Generate RSA keys and start creating licenses! 🚀
