# License System Security - Git Ignore Entries

## ⚠️ CRITICAL: Add these to .gitignore

To prevent accidentally committing sensitive license files, add these entries to your `.gitignore`:

```gitignore
# License System - NEVER COMMIT THESE FILES
keys/
*.pem
*_license.json
test_license.json
dev_license.json
trial_license.json

# User license directory
.tibmigrator/
```

## Why This Matters

### 🔐 Private Key Security
- `keys/private_key.pem` - Anyone with this can generate unlimited valid licenses
- If leaked, you must:
  1. Generate new RSA key pair
  2. Embed new public key in code
  3. Rebuild and redistribute package
  4. Regenerate all customer licenses

### 🎫 License File Security
- License files contain customer information
- Each license is machine-specific
- Leaking licenses doesn't compromise the system but violates privacy

## ✅ Recommended .gitignore

Add to your existing `.gitignore`:

```gitignore
# ============================================================
# License System Security
# ============================================================

# RSA Keys (CRITICAL - DO NOT COMMIT)
keys/
*.pem
private_key.pem
public_key.pem

# License Files (customer data)
*_license.json
test_license.json
dev_license.json
trial_license.json
commercial_license.json
academic_license.json

# User license storage
.tibmigrator/
~/.tibmigrator/

# License generator temp files
license_temp/
```

## 🚨 If Private Key Was Accidentally Committed

### Immediate Actions:

1. **Revoke the compromised key immediately**
2. **Generate new RSA key pair**
   ```powershell
   python tools/license_generator.py generate-keys --output-dir keys_v2
   ```

3. **Remove from Git history** (use BFG Repo-Cleaner or git-filter-repo)
   ```powershell
   # WARNING: This rewrites Git history
   git filter-repo --path keys/private_key.pem --invert-paths
   ```

4. **Force push to remote** (if already pushed)
   ```powershell
   git push origin main --force
   ```

5. **Notify all collaborators** to re-clone the repository

6. **Embed new public key** in `offline_validator.py`

7. **Rebuild package** with new key

8. **Regenerate all customer licenses** with new key pair

### Prevention:

- ✅ Add `.gitignore` BEFORE generating keys
- ✅ Use pre-commit hooks to block `.pem` files
- ✅ Keep keys outside repository directory
- ✅ Use Git secrets scanning tools

## 📋 Security Checklist

Before generating keys:
- [ ] `.gitignore` includes `keys/` and `*.pem`
- [ ] Repository security scanning enabled
- [ ] Pre-commit hooks configured
- [ ] Team trained on key security

After generating keys:
- [ ] Private key stored in secure vault
- [ ] Backup created in separate secure location
- [ ] Access restricted to authorized personnel only
- [ ] Key generation logged for audit trail

---

**Remember**: The security of your entire license system depends on keeping `private_key.pem` secret!
