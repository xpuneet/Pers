# TIBMigrator Offline License System

**Version**: 2.0 (Binary-Encoded Multi-Binding)  
**Updated**: November 18, 2025

Complete hardware-locked RSA-signed license system for TIBMigrator plugin (100% offline operation).

## 🎯 Overview

The TIBMigrator license system provides:

- ✅ **100% Offline** - No internet required after license installation
- ✅ **Binary-Encoded** - License content not human-readable (base64 obfuscation)
- ✅ **Multi-Binding Support** - 5 binding types: hardware, subnet, domain, multi, hybrid
- ✅ **RSA-2048 Signed** - Cryptographically secure, tamper-proof licenses
- ✅ **Feature Flags** - Granular control over 4 feature sets (11 MCP tools)
- ✅ **Time-Limited** - Support for trial, perpetual, and expiring licenses
- ✅ **Server Protection** - MCP server won't start without valid license
- ✅ **Runtime Enforcement** - Every MCP tool validates feature access

## 🆕 What's New in v2.0

| Feature | Description |
|---------|-------------|
| **Binary Encoding** | License content base64-encoded (not human-readable) |
| **Multi-Binding** | 5 binding types including network-based licenses |
| **Feature Enforcement** | All 11 MCP tools check license before execution |
| **Server Protection** | Server exits if license invalid (exit code 1) |
| **Skip-Binding Mode** | Allows license installation on vendor machine |
| **CLI Feature Flags** | `--disable-*` and `--enable-only` options |
| **Backward Compatible** | v1.0 plain JSON licenses still work |

## 📁 File Structure

```
tibmigrator/
├── src/tibmigrator/
│   ├── server.py                    # MCP server with license enforcement
│   └── license/
│       ├── __init__.py              # Module exports
│       ├── hardware_id.py           # Machine fingerprinting (5 binding types)
│       └── offline_validator.py     # RSA signature & multi-binding validation
├── tools/
│   └── license_generator.py         # Key generation & license creation
└── keys/                            # RSA keys (KEEP PRIVATE!)
    ├── private_key.pem              # Private key for signing (DO NOT DISTRIBUTE)
    └── public_key.pem               # Public key (embedded in code)
```

## 🔑 License Security Architecture

### 4-Layer Security System

```
┌─────────────────────────────────────────────────────────┐
│ Layer 1: Binary Encoding (Obfuscation)                  │
│ - License content base64-encoded                        │
│ - Not human-readable in text editor                     │
│ - Prevents casual inspection                            │
└─────────────────────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────────────────────┐
│ Layer 2: RSA-2048 Signature (Tamper Prevention)         │
│ - Cryptographic signature using private key             │
│ - Any modification breaks signature                     │
│ - Prevents sophisticated tampering                      │
└─────────────────────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────────────────────┐
│ Layer 3: Multi-Binding Validation (Usage Restriction)   │
│ - hardware: Single machine (MAC + hostname + UUID)      │
│ - subnet: Network range (192.168.1.0/24)                │
│ - domain: Company-wide (example.com)                    │
│ - multi: List of specific machines                      │
│ - hybrid: Combination (domain + subnet)                 │
└─────────────────────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────────────────────┐
│ Layer 4: Feature Flags (Capability Control)             │
│ - reverse_engineering: 3 tools                          │
│ - forward_engineering: 4 tools                          │
│ - csv_export: 1 tool                                    │
│ - document_generation: 3 tools                          │
└─────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Step 1: Generate RSA Key Pair (One-Time Setup)

```powershell
# Generate 2048-bit RSA key pair
python tools/license_generator.py generate-keys

# Output:
# ✅ Private key saved to: keys/private_key.pem
# ✅ Public key saved to: keys/public_key.pem
```

⚠️ **CRITICAL**: Keep `private_key.pem` SECURE! Anyone with this key can generate valid licenses.

### Step 2: Embed Public Key in Code

1. Open `keys/public_key.pem` and copy the entire content
2. Open `src/tibmigrator/license/offline_validator.py`
3. Replace `PUBLIC_KEY_PEM` constant (lines ~27-31) with your public key:

```python
PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA...
... (your actual public key content) ...
-----END PUBLIC KEY-----"""
```

### Step 3: Rebuild Package with Embedded Public Key

```powershell
# Rebuild with bytecode-only distribution (source protection)
python build_package.py --bytecode

# Package will be created in: dist/tibmigrator-2.1.3-py3-none-any.whl
```

### Step 4: Customer Gets Their Binding Information

#### Option A: Single Machine License (hardware binding)

Customer runs:
```powershell
tibmigrator get-machine-id
```

Output:
```
============================================================
🖥️  MACHINE HARDWARE ID
============================================================

Machine ID: a1b2c3d4e5f6...1234567890abcdef

Hardware Information:
  MAC Address: A1B2C3D4E5F6
  Hostname: CUSTOMER-PC
  Processor: Intel64 Family 6 Model 142 Stepping 12
  System: Windows
  System UUID: 12345678-1234-1234-1234-123456789012

📋 Send this Machine ID to obtain a license file.
============================================================
```

#### Option B: Network/Domain License

Customer provides:
- **Subnet binding**: Network CIDR (e.g., `192.168.1.0/24`)
- **Domain binding**: Company domain (e.g., `acme.corp.com`)
- **Multi binding**: List of 2-5 machine IDs
- **Hybrid binding**: Domain + subnet combination

### Step 5: Generate License for Customer

#### A. Single Machine License (Default)

```powershell
# Commercial license (perpetual, all features)
python tools/license_generator.py generate `
    --machine-id a1b2c3d4e5f6...1234567890abcdef `
    --customer "John Doe" `
    --company "Acme Corp" `
    --type commercial `
    --output acme_license.json
```

#### B. Trial License (30 days, all features)

```powershell
python tools/license_generator.py generate `
    --machine-id a1b2c3d4e5f6...1234567890abcdef `
    --customer "Jane Smith" `
    --company "Demo Inc" `
    --type trial `
    --days 30 `
    --output demo_trial.json
```

#### C. Network License (Subnet Binding)

```powershell
# Allow entire office network
python tools/license_generator.py generate `
    --binding-type subnet `
    --subnet 192.168.1.0/24 `
    --customer "DevOps Team" `
    --company "TechCorp" `
    --type commercial `
    --output network_license.json
```

#### D. Company-Wide License (Domain Binding)

```powershell
# Allow all machines in domain
python tools/license_generator.py generate `
    --binding-type domain `
    --domain acme.corp.com `
    --customer "IT Department" `
    --company "Acme Corp" `
    --type commercial `
    --output corporate_license.json
```

#### E. Multi-Machine License (Specific Machines)

```powershell
# Allow 5 specific developer machines
python tools/license_generator.py generate `
    --binding-type multi `
    --machine-ids id1,id2,id3,id4,id5 `
    --customer "Dev Team" `
    --company "StartupXYZ" `
    --type commercial `
    --output team_license.json
```

#### F. Hybrid License (Domain + Subnet)

```powershell
# Company domain + specific VPN subnet
python tools/license_generator.py generate `
    --binding-type hybrid `
    --domain acme.corp.com `
    --subnet 10.0.0.0/16 `
    --customer "Remote Team" `
    --company "Acme Corp" `
    --type commercial `
    --output hybrid_license.json
```

#### G. Feature-Limited License (Disable Specific Features)

```powershell
# Only reverse engineering + CSV export
python tools/license_generator.py generate `
    --machine-id a1b2c3d4e5f6...1234567890abcdef `
    --customer "Analyst User" `
    --company "DataCorp" `
    --type commercial `
    --enable-only reverse_engineering csv_export `
    --output limited_license.json

# Disable forward engineering
python tools/license_generator.py generate `
    --machine-id a1b2c3d4e5f6...1234567890abcdef `
    --customer "Review User" `
    --company "AuditCorp" `
    --type commercial `
    --disable-forward-engineering `
    --output review_license.json
```

Output:
```
📝 Generating COMMERCIAL license...
🔐 Encoding license to binary format (v2.0)...
✅ License generated: acme_license.json

📋 License Details:
   Format: Binary-Encoded (base64)
   Customer: John Doe
   Company: Acme Corp
   Type: COMMERCIAL
   Binding: hardware (a1b2c3d4e5f6...)
   Valid Until: Perpetual
   Features: reverse_engineering, forward_engineering, csv_export, document_generation

📤 Distribution:
   Send acme_license.json to customer
   Customer installs with: tibmigrator install-license acme_license.json

⚠️  License file content is binary-encoded (not human-readable)
```

### Step 6: Customer Installs License

```powershell
# Install license file
tibmigrator install-license C:\Downloads\acme_license.json

# Output:
# 📥 Installing license from: C:\Downloads\acme_license.json
# ✅ License installed successfully!
#    Location: C:\Users\John\.tibmigrator\license.json
```

### Step 7: Verify License Status

```powershell
tibmigrator license-status
```

Output:
```
============================================================
📜 LICENSE STATUS
============================================================

Status: ✅ VALID
Format: Binary-Encoded v2.0
Type: COMMERCIAL
Customer: John Doe
Company: Acme Corp
Binding: hardware (a1b2c3d4...)
Issued: 2025-11-18T10:30:00
Valid Until: Perpetual

Enabled Features:
  ✓ reverse_engineering (3 tools)
  ✓ forward_engineering (4 tools)
  ✓ csv_export (1 tool)
  ✓ document_generation (3 tools)

Protected MCP Tools: 11/11
============================================================
```

## 🔐 License File Format

### v2.0 Binary-Encoded Format (Current)

What customer sees (base64-encoded, not human-readable):

```json
{
  "format": "binary",
  "version": "2.0",
  "encoded_data": "eyJkYXRhIjogeyJtYWNoaW5lX2lkIjogImExYjJjM2Q0ZTVmNi4uLiIsICJjdXN0b21lcl9uYW1lIjogIkpvaG4gRG9lIiwgImNvbXBhbnkiOiAiQWNtZSBDb3JwIiwgInR5cGUiOiAiY29tbWVyY2lhbCIsICJpc3N1ZV9kYXRlIjogIjIwMjUtMTEtMThUMTA6MzA6MDAiLCAidmFsaWRfdW50aWwiOiBudWxsLCAiZmVhdHVyZXMiOiB7InJldmVyc2VfZW5naW5lZXJpbmciOiB0cnVlLCAiZm9yd2FyZF9lbmdpbmVlcmluZyI6IHRydWUsICJjc3ZfZXhwb3J0IjogdHJ1ZSwgImRvY3VtZW50X2dlbmVyYXRpb24iOiB0cnVlfSwgImJpbmRpbmdfaW5mbyI6IHsiYmluZGluZ190eXBlIjogImhhcmR3YXJlIiwgIm1hY2hpbmVfaWQiOiAiYTFiMmMzZDRlNWY2Li4uIn0sICJ2ZXJzaW9uIjogIjIuMCJ9LCAic2lnbmF0dXJlIjogIkJhc2U2NC1lbmNvZGVkIFJTQSBzaWduYXR1cmUuLi4ifQ=="
}
```

### Internal Structure (after decoding)

```json
{
  "data": {
    "customer_name": "John Doe",
    "company": "Acme Corp",
    "type": "commercial",
    "issue_date": "2025-11-18T10:30:00",
    "valid_until": null,
    "features": {
      "reverse_engineering": true,
      "forward_engineering": true,
      "csv_export": true,
      "document_generation": true
    },
    "binding_info": {
      "binding_type": "hardware",
      "machine_id": "a1b2c3d4e5f6...1234567890abcdef"
    },
    "version": "2.0"
  },
  "signature": "Base64-encoded RSA signature..."
}
```

### v1.0 Plain JSON Format (Legacy, still supported)

```json
{
  "data": {
    "machine_id": "a1b2c3d4e5f6...1234567890abcdef",
    "customer_name": "John Doe",
    "company": "Acme Corp",
    "type": "commercial",
    "issue_date": "2025-11-14T10:30:00",
    "valid_until": null,
    "features": {
      "reverse_engineering": true,
      "forward_engineering": true,
      "csv_export": true,
      "document_generation": true
    },
    "version": "1.0"
  },
  "signature": "Base64-encoded RSA signature..."
}
```

## 📋 CLI Commands

| Command | Description | Example |
|---------|-------------|---------|
| `get-machine-id` | Display machine hardware ID | `tibmigrator get-machine-id` |
| `install-license <path>` | Install license file | `tibmigrator install-license license.json` |
| `license-status` | Show current license status | `tibmigrator license-status` |
| `remove-license` | Remove installed license | `tibmigrator remove-license` |

## 🎯 Feature Flags & MCP Tool Mapping

### Feature: `reverse_engineering` (3 tools)
| MCP Tool | Description |
|----------|-------------|
| `tibco_reverse_engineer` | Main reverse engineering workflow |
| `process_list` | List and select processes |
| `validate_document_generation` | Verify extraction/mapping docs |

### Feature: `forward_engineering` (4 tools)
| MCP Tool | Description |
|----------|-------------|
| `generate_technical_design` | Create technical design doc |
| `generate_migrated_code` | Generate target platform code |
| `validate_forward_engineering` | Verify tech design/code |
| `generate_srs_sections_7_11` | Generate SRS sections 7-11 |

### Feature: `csv_export` (1 tool)
| MCP Tool | Description |
|----------|-------------|
| `export_mappings_to_csv` | Export mappings to CSV format |

### Feature: `document_generation` (3 tools)
| MCP Tool | Description |
|----------|-------------|
| `generate_extraction_document` | Generate extraction.md |
| `generate_mapping_document` | Generate mapping_specification.md |
| `generate_srs_sections_1_6` | Generate SRS sections 1-6 |

**Total Protected Tools**: 11 MCP tools

## 🔒 Multi-Binding Types

### 1. Hardware Binding (Single Machine)

**Use Case**: Individual developer licenses, single-server deployments

```powershell
python tools/license_generator.py generate `
    --binding-type hardware `
    --machine-id a1b2c3d4e5f6...1234567890abcdef `
    --customer "John Doe" `
    --type commercial
```

**Validation**: Exact match of MAC + hostname + UUID

**Pros**: Tightest security, prevents sharing  
**Cons**: Requires new license on hardware change

---

### 2. Subnet Binding (Network Range)

**Use Case**: Office networks, cloud VPCs, developer teams

```powershell
python tools/license_generator.py generate `
    --binding-type subnet `
    --subnet 192.168.1.0/24 `
    --customer "DevOps Team" `
    --type commercial
```

**Validation**: Machine IP must be in subnet range  
**Supports**: /8 to /32 CIDR notation

**Pros**: Flexible for network environments, no hardware lock  
**Cons**: Works on entire subnet (less restrictive)

---

### 3. Domain Binding (Company-Wide)

**Use Case**: Corporate licenses, Active Directory environments

```powershell
python tools/license_generator.py generate `
    --binding-type domain `
    --domain acme.corp.com `
    --customer "IT Department" `
    --type commercial
```

**Validation**: Machine hostname ends with domain  
**Example Matches**: `dev-server.acme.corp.com`, `build01.acme.corp.com`

**Pros**: Simple company-wide deployment  
**Cons**: Relies on hostname (can be spoofed)

---

### 4. Multi Binding (Specific Machines)

**Use Case**: Team licenses, build farm, specific servers

```powershell
python tools/license_generator.py generate `
    --binding-type multi `
    --machine-ids id1,id2,id3,id4,id5 `
    --customer "Dev Team" `
    --type commercial
```

**Validation**: Machine ID must match one of the list (2-10 machines)

**Pros**: Controlled set of machines, no network dependency  
**Cons**: Requires updating license to add/remove machines

---

### 5. Hybrid Binding (Domain + Subnet)

**Use Case**: Enterprise licenses, VPN + corporate domain

```powershell
python tools/license_generator.py generate `
    --binding-type hybrid `
    --domain acme.corp.com `
    --subnet 10.0.0.0/16 `
    --customer "Remote Team" `
    --type commercial
```

**Validation**: Machine must match BOTH domain AND subnet

**Pros**: Tightest network-based security  
**Cons**: More complex configuration

## 🛡️ Security Features

### 1. Binary Encoding (Obfuscation Layer)
- License content base64-encoded in v2.0 format
- Not human-readable in text editors
- Prevents casual inspection of:
  - Customer information
  - Feature flags
  - Expiration dates
  - Binding configuration

### 2. RSA-2048 Signatures (Tamper Prevention)
- Licenses signed with 2048-bit RSA private key
- Signatures verified using embedded public key
- Any modification breaks signature → license rejected
- Protects against:
  - Feature flag manipulation
  - Expiration date changes
  - Binding circumvention
  - Customer info forgery

### 3. Multi-Binding Validation (Usage Restriction)
- License locked to specific machine(s) or network
- 5 binding types for different use cases
- Fingerprint includes (hardware binding):
  - MAC address (primary network interface)
  - Hostname
  - Processor architecture
  - System UUID (platform-specific)

### 4. Server-Level Protection
- MCP server validates license on startup
- Server exits with error code 1 if:
  - License file missing
  - License signature invalid
  - License expired
  - Machine/network binding failed
- No tools accessible without valid license

### 5. Runtime Feature Enforcement
- Every MCP tool checks feature flag before execution
- Tools blocked if feature disabled in license
- Error message indicates which feature required
- 11 MCP tools protected across 4 feature sets

### 6. Offline Validation
- No internet connection required
- No phone-home behavior
- Private key never leaves your system
- All validation done locally

### 7. Bytecode Distribution
- Source code compiled to `.pyc` bytecode
- Public key embedded in bytecode
- Source protection via bytecode-only wheels
- Harder to reverse-engineer validation logic

## 🔄 License Types

| Type | Description | Typical Use Case | Default Duration |
|------|-------------|------------------|------------------|
| `trial` | Time-limited evaluation | 14-30 day trials | 14 days |
| `commercial` | Full commercial license | Paying customers | Perpetual |
| `academic` | Educational/research use | Universities, research labs | 1 year |
| `developer` | Internal development | Your own development team | Perpetual |

## 🎛️ Feature Control Examples

### Example 1: Full Access (All Features)
```powershell
python tools/license_generator.py generate `
    --machine-id abc123... `
    --customer "Premium User" `
    --type commercial
# All 4 features enabled (default)
# All 11 MCP tools accessible
```

### Example 2: Analysis Only (No Code Generation)
```powershell
python tools/license_generator.py generate `
    --machine-id abc123... `
    --customer "Analyst User" `
    --type commercial `
    --enable-only reverse_engineering csv_export document_generation
# Only analysis, mapping, CSV export
# forward_engineering disabled (4 tools blocked)
```

### Example 3: Code Generation Only
```powershell
python tools/license_generator.py generate `
    --machine-id abc123... `
    --customer "Developer User" `
    --type commercial `
    --enable-only forward_engineering
# Only code generation tools
# Reverse engineering, CSV, docs disabled (7 tools blocked)
```

### Example 4: Disable Specific Feature
```powershell
python tools/license_generator.py generate `
    --machine-id abc123... `
    --customer "Limited User" `
    --type commercial `
    --disable-csv-export
# All features except CSV export
# 10 tools accessible, export_mappings_to_csv blocked
```

### Example 5: Trial with Limited Features
```powershell
python tools/license_generator.py generate `
    --machine-id abc123... `
    --customer "Trial User" `
    --type trial `
    --days 30 `
    --enable-only reverse_engineering document_generation
# 30-day trial, only reverse engineering + docs
# 6 tools accessible (reverse: 3, docs: 3)
```

## ⚠️ Important Security Notes

### DO:
- ✅ Keep `private_key.pem` in a SECURE location (encrypted vault)
- ✅ Use different key pairs for dev/prod environments
- ✅ Rotate keys periodically (every 1-2 years)
- ✅ Backup private key in secure vault (offline backup)
- ✅ Use hardware security modules (HSM) for enterprise
- ✅ Test skip-binding mode when generating licenses on vendor machine
- ✅ Use binary encoding (v2.0) for all new licenses
- ✅ Choose appropriate binding type for customer use case
- ✅ Document which features are enabled in license metadata

### DON'T:
- ❌ Commit `private_key.pem` to version control
- ❌ Share private key via email/chat/cloud storage
- ❌ Store private key on shared drives or network shares
- ❌ Include private key in package distribution
- ❌ Reuse same license file across machines (hardware binding)
- ❌ Generate licenses with all bindings enabled (choose one)
- ❌ Use plain JSON v1.0 for new licenses (use v2.0 binary)
- ❌ Enable all features for trial licenses (use --enable-only)
- ❌ Ignore signature validation errors (potential tampering)

## 🔧 Troubleshooting

### License Validation Failed

**Error**: "License signature verification failed"
- **Cause**: License file tampered, corrupted, or wrong public key
- **Solution**: Request new license file from vendor

**Error**: "License is bound to different hardware"
- **Cause**: Hardware changed (e.g., new network card, VM migration)
- **Solution**: Get new license with current machine ID (`tibmigrator get-machine-id`)

**Error**: "License expired on YYYY-MM-DD"
- **Cause**: Trial/time-limited license expired
- **Solution**: Purchase commercial license or request extension

**Error**: "Machine not in licensed subnet range"
- **Cause**: Subnet binding validation failed (wrong network)
- **Solution**: Connect to correct network or request new license

**Error**: "Machine domain does not match license"
- **Cause**: Domain binding validation failed
- **Solution**: Join correct domain or use VPN, or request new license

### Server Won't Start

**Error**: "No license file found"
- **Cause**: License not installed
- **Solution**: Run `tibmigrator install-license <path>`

**Error**: "Import .license could not be resolved"
- **Cause**: License module not built/installed
- **Solution**: Rebuild package with `python build_package.py --bytecode`

**Error**: "License validation failed" (server exits with code 1)
- **Cause**: Invalid/expired/wrong-machine license
- **Solution**: Check `license-status`, install correct license

### Feature Access Denied

**Error**: "Feature 'reverse_engineering' not enabled in license"
- **Cause**: MCP tool requires disabled feature
- **Solution**: Request new license with feature enabled

**Error**: "Feature 'csv_export' not enabled in license"
- **Cause**: CSV export disabled in license
- **Solution**: Upgrade license or use different tool

### Binary Encoding Issues

**Error**: "Failed to decode base64 license"
- **Cause**: License file corrupted during transfer
- **Solution**: Re-download license file (ensure binary transfer mode)

**Error**: "Unsupported license format version: X.X"
- **Cause**: Future version not supported by current validator
- **Solution**: Update TIBMigrator package to latest version

### Multi-Binding Validation

**Error**: "Failed to install license: binding validation failed"
- **Cause**: Vendor generating license on different machine
- **Solution**: This is EXPECTED during generation - validator uses skip-binding mode during install

**Error**: "At least one of machine_id, subnet, domain must be provided"
- **Cause**: No binding specified during license generation
- **Solution**: Add `--machine-id`, `--subnet`, or `--domain` to generate command

## 📖 Developer Guide

### Adding New Features

To add license-controlled features:

1. **Add feature flag to license generation** (`tools/license_generator.py`):
```python
features = {
    'reverse_engineering': True,
    'forward_engineering': True,
    'csv_export': True,
    'document_generation': True,
    'new_feature': True  # Add here
}
```

2. **Add CLI flag** (in `license_generator.py`):
```python
generate_parser.add_argument(
    '--disable-new-feature',
    action='store_true',
    help='Disable new_feature'
)
```

3. **Add feature check in MCP tool** (`src/tibmigrator/server.py`):
```python
@mcp.tool()
async def my_new_tool(param1: str) -> str:
    """Tool description"""
    check_feature_enabled("new_feature")  # Add this line first
    
    # Tool implementation
    return "result"
```

### Custom Validation Logic

Extend `OfflineLicenseValidator` class:

```python
from tibmigrator.license import OfflineLicenseValidator, LicenseException

class CustomValidator(OfflineLicenseValidator):
    def validate_license(self, skip_binding_check=False):
        # Call parent validation
        license_info = super().validate_license(skip_binding_check)
        
        # Add custom checks
        if license_info.get('type') == 'trial':
            # Limit trial to 100 executions
            self._check_execution_count()
        
        return license_info
```

### Testing Multi-Binding Types

```python
# Test hardware binding
python tools/license_generator.py generate \
    --binding-type hardware \
    --machine-id $(tibmigrator get-machine-id | grep "Machine ID:" | cut -d' ' -f3)

# Test subnet binding
python tools/license_generator.py generate \
    --binding-type subnet \
    --subnet 192.168.1.0/24

# Test domain binding
python tools/license_generator.py generate \
    --binding-type domain \
    --domain $(hostname -d)

# Test multi binding
python tools/license_generator.py generate \
    --binding-type multi \
    --machine-ids id1,id2,id3

# Test hybrid binding
python tools/license_generator.py generate \
    --binding-type hybrid \
    --domain example.com \
    --subnet 10.0.0.0/16
```

### Testing Feature Enforcement

```python
# Create license with single feature
python tools/license_generator.py generate \
    --machine-id abc123... \
    --enable-only reverse_engineering \
    --output test_license.json

# Install license
tibmigrator install-license test_license.json

# Try to use disabled tool (should fail)
# This will raise: "Feature 'forward_engineering' not enabled in license"
```

### Skip-Binding Mode (Vendor Use)

When generating licenses on vendor machine (different from customer):

```python
from tibmigrator.license.offline_validator import OfflineLicenseValidator

# This will skip binding validation but still verify signature
validator = OfflineLicenseValidator()
license_info = validator.validate_license(skip_binding_check=True)
# ✅ Validates: signature, expiration
# ⏭️ Skips: hardware/subnet/domain binding
```

This allows vendor to:
1. Generate license with customer's machine ID
2. Test signature validity
3. Customer installs license (full validation on their machine)

## 🔐 Attack Resistance Analysis

### Attack 1: Binary Decode and Feature Manipulation

**Attack**: Decode base64 license, change features to all `true`, re-encode

**Defense**:
- ✅ RSA signature breaks when data modified
- ✅ Signature verification fails → license rejected
- ✅ Cannot re-sign without private key

**Result**: ❌ Attack FAILS

---

### Attack 2: Copy License to Different Machine

**Attack**: Copy `.json` license file to unauthorized machine

**Defense** (Hardware Binding):
- ✅ Machine ID validation fails (different MAC/UUID)
- ✅ License rejected on different machine

**Defense** (Subnet Binding):
- ✅ IP address check fails if outside subnet
- ✅ Works only within authorized network

**Result**: ❌ Attack FAILS (hardware), ⚠️ PARTIAL (subnet within range)

---

### Attack 3: Spoof Hardware ID

**Attack**: Modify MAC address to match licensed machine

**Defense**:
- ✅ Multi-factor fingerprint (MAC + hostname + UUID + processor)
- ✅ All factors must match
- ✅ System UUID hard to spoof

**Result**: ❌ Attack DIFFICULT (requires multiple spoofs)

---

### Attack 4: Remove Expiration Date

**Attack**: Decode license, set `valid_until: null` (perpetual)

**Defense**:
- ✅ RSA signature breaks when data modified
- ✅ Cannot re-sign without private key

**Result**: ❌ Attack FAILS

---

### Attack 5: Extract Public Key from Bytecode

**Attack**: Decompile `.pyc`, extract public key, generate fake private key

**Defense**:
- ✅ Public key extraction is EXPECTED (not a vulnerability)
- ✅ Cannot generate matching private key from public key (RSA math)
- ✅ Would need to factor 2048-bit RSA modulus (computationally infeasible)

**Result**: ❌ Attack FAILS (cryptographic impossibility)

---

### Attack 6: Replay v1.0 License (Plain JSON)

**Attack**: Use old v1.0 format to bypass binary encoding

**Defense**:
- ✅ v1.0 still validated (signature + binding)
- ✅ Feature flags still enforced
- ✅ Same security, just readable format

**Result**: ⚠️ PARTIAL (works but still validated, just not obfuscated)

---

### Attack 7: Skip License Check in Code

**Attack**: Modify server code to skip `check_feature_enabled()`

**Defense**:
- ✅ Code distributed as bytecode (`.pyc`)
- ✅ Harder to modify bytecode
- ✅ Server-level license check on startup (exit code 1 if invalid)

**Result**: ⚠️ DIFFICULT (requires bytecode modification, technical skill)

---

## � Best Practices Summary

### For Vendors

1. **Key Management**:
   - Generate unique RSA keys per product/version
   - Store private key in HSM or encrypted vault
   - Never commit private key to version control
   - Rotate keys every 1-2 years

2. **License Generation**:
   - Use binary encoding (v2.0) for all new licenses
   - Choose binding type based on customer use case
   - Use `--enable-only` for trial licenses (limit features)
   - Test with skip-binding mode before sending to customer

3. **Distribution**:
   - Send only `.json` license file to customer
   - Include installation instructions
   - Provide `get-machine-id` command in docs
   - Explain binding type restrictions

4. **Package Building**:
   - Use `--bytecode` flag to compile source to `.pyc`
   - Embed public key in validator before building
   - Test package installation before distribution

### For Customers

1. **Installation**:
   - Run `tibmigrator get-machine-id` to get machine ID
   - Send machine ID to vendor
   - Receive `.json` license file
   - Install with `tibmigrator install-license <path>`

2. **Verification**:
   - Check status with `tibmigrator license-status`
   - Verify all required features enabled
   - Test MCP server starts successfully
   - Confirm all needed tools accessible

3. **Maintenance**:
   - Backup license file (stored in `~/.tibmigrator/`)
   - Re-install after OS reinstall
   - Request new license if hardware changes
   - Monitor expiration dates (trial/academic licenses)

---

## 📊 Feature Matrix

| License Type | Duration | reverse_engineering | forward_engineering | csv_export | document_generation | Binding Types Supported |
|--------------|----------|---------------------|---------------------|------------|---------------------|-------------------------|
| Trial | 14-30 days | Optional* | Optional* | Optional* | Optional* | hardware, subnet, domain |
| Commercial | Perpetual | ✅ Default | ✅ Default | ✅ Default | ✅ Default | All 5 types |
| Academic | 1 year | ✅ Default | ✅ Default | ✅ Default | ✅ Default | All 5 types |
| Developer | Perpetual | ✅ Default | ✅ Default | ✅ Default | ✅ Default | All 5 types |

\* Use `--enable-only` to customize trial features

---

## 🔗 Related Documentation

- **Feature Licensing Guide**: `FEATURE_LICENSING_COMPLETE.md`
- **License Generator CLI**: `tools/license_generator.py --help`
- **Validator Module**: `src/tibmigrator/license/offline_validator.py`
- **Server Implementation**: `src/tibmigrator/server.py`

---

## �🆘 Support

For license-related issues:
- 📧 Email: support@tibmigrator.com
- 📚 Docs: https://docs.tibmigrator.com/licensing
- 🐛 Issues: https://github.com/tibmigrator/tibmigrator/issues

---

**Generated**: November 18, 2025  
**Version**: 2.0 (Binary-Encoded Multi-Binding)  
**System**: Hardware-Locked Offline License with Feature Enforcement
