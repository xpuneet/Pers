# License Bypass Guide for Development/Testing

**Date**: November 19, 2025  
**Purpose**: Enable MCP server to run without license validation during development

---

## ✅ Problem Solved

**Issue**: MCP server was failing to start with error:
```
"The MCP TIBCO reverse engineering tool still cannot run because the license is not validated."
```

**Root Cause**: 
- License validation enforcement was blocking server startup
- No license file installed or binding validation failed
- Server returned exit code 1 and refused to start

**Solution**: 
- Added environment variable bypass: `TIBMIGRATOR_BYPASS_LICENSE=true`
- Server now starts with all features enabled (development mode)

---

## 🚀 Quick Start

### Option 1: Use PowerShell Script (Recommended)

```powershell
# Run the development server script
.\start_server_dev.ps1
```

### Option 2: Use Batch File

```batch
# Run the development server batch file
start_server_dev.bat
```

### Option 3: Set Environment Variable Manually

**PowerShell:**
```powershell
$env:TIBMIGRATOR_BYPASS_LICENSE = "true"
python -m tibmigrator.server
```

**Command Prompt:**
```batch
set TIBMIGRATOR_BYPASS_LICENSE=true
python -m tibmigrator.server
```

### Option 4: MCP Configuration File (For Claude Desktop)

The `mcp.json` file has been updated with the bypass environment variable:

```json
{
  "servers": {
    "calculator": {
      "command": "C:\\Python\\IPM_tibco_migrator_plugin\\.venv\\Scripts\\python.exe",
      "args": ["C:\\Python\\IPM_tibco_migrator_plugin\\tibmigrator.py"],
      "env": {
        "PYTHONPATH": "C:\\Python\\IPM_tibco_migrator_plugin\\sample-mcp-server",
        "TIBMIGRATOR_BYPASS_LICENSE": "true"
      }
    }
  }
}
```

**Action Required**: 
- Restart Claude Desktop application
- The MCP server will now start with license bypass enabled

---

## 📋 What Changed

### 1. Server Code (`src/tibmigrator/server.py`)

Added environment variable check:
```python
# Check if license validation should be bypassed (for development/testing)
bypass_license = os.getenv('TIBMIGRATOR_BYPASS_LICENSE', 'false').lower() in ['true', '1', 'yes']

if LICENSE_ENABLED and not bypass_license:
    # Validate license normally
    ...
else:
    if bypass_license:
        logger.warning("⚠️  LICENSE VALIDATION BYPASSED")
        logger.warning("   Environment variable TIBMIGRATOR_BYPASS_LICENSE=true")
        logger.warning("   All features are enabled (development mode)")
        logger.warning("   ⚠️  DO NOT USE IN PRODUCTION!")
```

### 2. Helper Scripts Created

- **start_server_dev.ps1** - PowerShell script to start server with bypass
- **start_server_dev.bat** - Batch script to start server with bypass

### 3. MCP Configuration Updated

- **mcp.json** - Added `TIBMIGRATOR_BYPASS_LICENSE: "true"` to environment variables

---

## 🧪 Testing the Fix

1. **Restart Claude Desktop** (if using MCP with Claude)
   - Close Claude Desktop completely
   - Reopen Claude Desktop
   - MCP server will auto-start with bypass enabled

2. **Verify Server Started**
   
   Check server logs for:
   ```
   ⚠️  LICENSE VALIDATION BYPASSED
      Environment variable TIBMIGRATOR_BYPASS_LICENSE=true
      All features are enabled (development mode)
      ⚠️  DO NOT USE IN PRODUCTION!
   ```

3. **Test MCP Tool**
   
   Try calling the TIBCO reverse engineering tool from Claude or any MCP client.

---

## 🔐 Production Deployment

### ⚠️ WARNING: Do NOT use bypass in production!

For production deployment, you MUST:

1. **Generate RSA Keys**
   ```powershell
   python tools/license_generator.py generate-keys
   ```

2. **Embed Public Key**
   - Copy `keys/public_key.pem` content
   - Replace `PUBLIC_KEY_PEM` in `src/tibmigrator/license/offline_validator.py`

3. **Generate License**
   ```powershell
   # Get machine ID
   python -c "from src.tibmigrator.license.hardware_id import get_machine_id; print(get_machine_id())"
   
   # Generate license
   python tools/license_generator.py generate \
       --machine-id <MACHINE_ID> \
       --customer "Production User" \
       --company "Your Company" \
       --type commercial \
       --output production_license.json
   ```

4. **Install License**
   ```powershell
   # Install via CLI (if available)
   tibmigrator install-license production_license.json
   
   # OR manually copy to:
   # Windows: C:\Users\<username>\.tibmigrator\license.json
   # Linux/Mac: ~/.tibmigrator/license.json
   ```

5. **Remove Bypass from Configuration**
   
   Remove or set to `false` in `mcp.json`:
   ```json
   {
     "env": {
       "TIBMIGRATOR_BYPASS_LICENSE": "false"
     }
   }
   ```

---

## 🛠️ Troubleshooting

### Issue: Server still won't start

**Check 1**: Verify environment variable is set
```powershell
# PowerShell
echo $env:TIBMIGRATOR_BYPASS_LICENSE

# Should output: true
```

**Check 2**: Check server logs
- Look for license validation messages
- Verify bypass warning appears

**Check 3**: Restart MCP client
- If using Claude Desktop, completely close and reopen
- Environment variables are loaded on startup

### Issue: "License not validated" error persists

This means the `check_feature_enabled()` function is being called but `VALIDATED_LICENSE` is `None`.

**Solution**: The server needs to start successfully first. Ensure:
1. Environment variable is set in `mcp.json`
2. Claude Desktop is restarted
3. Server startup logs show bypass warning

---

## 📊 Feature Status with Bypass

When bypass is enabled, ALL features are accessible:

| Feature | Tools | Status |
|---------|-------|--------|
| reverse_engineering | 3 tools | ✅ Enabled |
| forward_engineering | 4 tools | ✅ Enabled |
| csv_export | 1 tool | ✅ Enabled |
| document_generation | 3 tools | ✅ Enabled |

**Total**: All 11 MCP tools available

---

## 📖 Related Documentation

- `LICENSE_SYSTEM_README.md` - Complete license system documentation
- `LICENSE_IMPLEMENTATION_SUMMARY.md` - Implementation details
- `FEATURE_LICENSING_COMPLETE.md` - Feature enforcement documentation

---

## ✅ Summary

### What You Need to Do Now:

1. ✅ **Restart Claude Desktop** (environment variable now set in mcp.json)
2. ✅ **Test MCP Tool** - Try calling `tibco_reverse_engineer` again
3. ✅ **Verify** - Check server logs for bypass warning

### Expected Outcome:

- Server starts successfully with license bypass
- All 11 MCP tools are accessible
- Warning message appears in logs (this is normal for dev mode)

### For Production:

- Generate and install proper license
- Remove bypass environment variable
- Deploy with license enforcement enabled

---

**Status**: ✅ BYPASS ENABLED - Ready for Development/Testing  
**Security**: ⚠️ Development Mode - Do NOT use in production  
**Next Step**: Restart Claude Desktop and test MCP tools
